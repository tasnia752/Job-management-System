import pymongo
from flask import Flask, render_template, request, redirect, session


client = pymongo.MongoClient("mongodb://localhost:27017/")
mydb = client["jobboard"]
user = mydb["user"]
jobpost = mydb["jobpost"]
feedback = mydb["feedback"]
applyjob = mydb["applyjob"]

app = Flask(__name__)
app.config['SECRET_KEY'] = "app secret key"


@app.route('/', methods=["GET", "POST"])
def home():
    if "mail" in session.keys():
         user_list = list(user.find({"email": session["mail"]}))

         for i in user_list:
             user_name = i['name']

    else:
        user_name = "no user"

    job_list = list(jobpost.find())

    return render_template("home.html", **locals())


@app.route('/home', methods=["GET", "POST"])
def home1():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    job_list = list(jobpost.find())

    return render_template("home.html", **locals())


@app.route('/about', methods=["GET", "POST"])
def about():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    return render_template("about.html", **locals())


@app.route('/services', methods=["GET", "POST"])
def services():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    return render_template("services.html", **locals())


@app.route('/contact', methods=["GET", "POST"])
def contact():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    if request.method == 'POST':

        d = dict()
        d["name"] = request.form["name"]
        d["email"] = request.form["mail"]
        d["phone"] = request.form["phone"]
        d["msg"] = request.form["msg"]

        feedback.insert_one(d)

        return render_template("home.html", **locals())

    return render_template("contact.html", **locals())


@app.route('/postjob', methods=["GET", "POST"])
def postjob():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']
            user_mail = i['email']

    else:
        user_name = "no user"

    error_msg = ""
    if request.method == 'POST':
        valid = 1

        if request.form["title"] == "":
            valid = 0
            error_msg = "You must Enter Job Title"
        if request.form["region"] == "":
            valid = 0
            error_msg = "You must Enter Job Region"

        if request.form["type"] == "":
            valid = 0
            error_msg = "You must Enter Job Type"

        if request.form["deadline"] == "":
            valid = 0
            error_msg = "You must Enter Job Application Deadline"

        if user_name == "no user":
            if request.form["buttonID"] == "save":
                return render_template("login.html", **locals())

        if valid == 1:
            d1 = dict()
            d1["email"] = user_mail
            d1["logo"] = request.form['logo']
            d1["title"] = request.form["title"]
            d1["region"] = request.form["region"]
            d1["type"] = request.form["type"]
            d1["vacancy"] = request.form["vacancy"]
            d1["experience"] = request.form["experience"]
            d1["salary"] = request.form["salary"]
            d1["gender"] = request.form["gender"]
            d1["deadline"] = request.form["deadline"]
            d1["image"] = request.form["img"]
            d1["detail"] = request.form["detail"]

            print(d1)

            jobpost.insert_one(d1)

            return render_template("home.html", **locals())

        elif valid == 0:
            return render_template("postjob.html", **locals())

    return render_template("postjob.html", **locals())


@app.route('/login', methods=["GET", "POST"])
def login():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    if request.method == 'POST':
        umail = request.form["email"]
        pass1 = request.form["psw"]
        find = list(user.find({"email": umail, "password": pass1}))
        lg_msg = ""

        if bool(find):
            session["mail"] = request.form["email"]
            return redirect("/")
        else:
            lg_msg = "Invalid password or user name"

    return render_template("login.html", **locals())


@app.route('/registration', methods=["GET", "POST"])
def registration():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    name_msg = ""
    email_msg = ""
    pass_msg = ""
    if request.method == 'POST':
        valid = True

        umail = request.form["email"]
        user_mail = list(user.find({"email": umail}))
        for i in user_mail:
            u_mail = i['email']
            if u_mail == umail:
                valid = False
                email_msg = "You Can't create two account with one Email"
            else:
                valid = True

        if len(request.form["name"]) < 2:
            valid = False
            name_msg = "Name must be more than 1 letter"
        if "@" not in umail:
            valid = False
            email_msg = "Email format should contains @"

        if request.form["psw"] != request.form["psw-repeat"]:
            valid = False
            pass_msg = "password must be matched"
        if valid:
            d = dict()
            d["name"] = request.form["name"]
            d["password"] = request.form["psw"]
            d["email"] = request.form["email"]

            user.insert_one(d)
            return render_template("login.html", **locals())

    return render_template("registration.html", **locals())


@app.route('/view', methods=["GET", "POST"])
def view():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    job_list = list(jobpost.find())
    for i in job_list:
        logo = i["logo"]
        title = i["title"]
        region = i["region"]
        type = i["type"]
        vacancy = i["vacancy"]
        experience = i["experience"]
        salary = i["salary"]
        gender = i["gender"]
        deadline = i["deadline"]
        image = i["image"]
        detail = i["detail"]

    return render_template("view.html", **locals())


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']
            user_mail = i['email']

    else:
        user_name = "no user"

    return render_template("profile.html", **locals())


@app.route('/apply', methods=["GET", "POST"])
def apply():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']
            user_mail = i['email']

    else:
        user_name = "no user"

    error_msg = ""
    if request.method == 'POST':
        valid = 1

        if request.form["cv"] == "":
            valid = 0
            error_msg = "You must upload your CV"

        if user_name == "no user":
            if request.form["buttonID"] == "apply":
                return render_template("login.html", **locals())

        if valid == 1:
            d = dict()
            d["name"] = user_name
            d["email"] = user_mail
            d["cv"] = request.form["cv"]
            d["phone"] = request.form["phone"]

            applyjob.insert_one(d)

            return render_template("home.html", **locals())

        elif valid == 0:
            return render_template("apply.html", **locals())

    return render_template("apply.html", **locals())


@app.route('/viewall', methods=["GET", "POST"])
def viewall():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    job_list = list(jobpost.find())

    return render_template("viewall.html", **locals())


@app.route('/myjobpost', methods=["GET", "POST"])
def myjobpost():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    job_list = list(jobpost.find())

    return render_template("myjobpost.html", **locals())



@app.route('/viewapply', methods=["GET", "POST"])
def viewapply():
    if "mail" in session.keys():
        user_list = list(user.find({"email": session["mail"]}))

        for i in user_list:
            user_name = i['name']

    else:
        user_name = "no user"

    job_list = list(jobpost.find())
    for i in job_list:
        title = i["title"]
        region = i["region"]
        type = i["type"]

    job_apply = list(applyjob.find())
    for j in job_apply:
        name = j["name"]
        phone = j["phone"]
        cv = j["cv"]

    return render_template("viewapply.html", **locals())



@app.route('/logout', methods=['GET', 'POST'])
def logout():
    session.clear()
    return redirect("/")



if __name__ == "__main__":
    app.run(host='127.0.0.1', port=5007)
    #serve(app, host='127.0.0.1', port=5002)
    #serve(app, host='0.0.0.0', port=80)
