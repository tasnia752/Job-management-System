
function noUserSaveJobFunction(){
  location.replace("login")
}

function cancelJobPostFunction(){
  location.replace("postjob")
}

viewFunction(){
location.replace("view")
}